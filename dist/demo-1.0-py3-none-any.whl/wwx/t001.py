class A:
    @classmethod
    def rec(self):
        print(self)

A.rec()